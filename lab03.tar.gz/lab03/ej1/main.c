#include <stdlib.h>
#include <stdio.h>

#define MAX_SIZE 1000

static void dump(char a[], unsigned int length) {
    printf("\"");
    for (unsigned int j=0u; j < length; j++) {
        printf("%c", a[j]);
    }
    printf("\"");
    printf("\n\n");
}

unsigned int data_from_file(const char *filepath,
                            unsigned int indexes[],
                            char letters[],
                            unsigned int max_size){
    FILE *file = fopen(filepath, "r");
    if (file == NULL) {
        fprintf(stderr, "File does not exist.\n");
        exit(EXIT_FAILURE);
        }

    unsigned int count = 0;
    
    int index;
    
    char letter;

    while (!feof(file) && count < max_size && fscanf(file, "%d -> *%c*", &index, &letter) == 2) {
        indexes[count] = index;
        letters[count] = letter;
        count++;
    }

    fclose(file);
    return count;
}

void array_sorted(char sorted[], char letters[], unsigned int index[], unsigned int length) {
    for (unsigned int i = 0; i < length; i++) {
            sorted[index[i]] = letters[i];
    }

}

char *parse_filepath(int argc, char *argv[]) {
    /* Parse the filepath given by command line argument. */
    char *result = NULL;

    if (argc < 2){
        
        exit(EXIT_FAILURE);
    
    }

    result = argv[1];

    return result;
}

int main(int argc, char *argv[]) {

    const char *file = parse_filepath(argc, argv);

    unsigned int indexes[MAX_SIZE];
    
    char letters[MAX_SIZE];
    
    char sorted[MAX_SIZE];
    
    unsigned int length = data_from_file(file, indexes, letters, MAX_SIZE);

    array_sorted(sorted, letters, indexes, length);

    dump(sorted, length);

    return EXIT_SUCCESS;
}