#ifndef _UTILS_H
#define _UTILS_H

#include <stdio.h>
#include <stdbool.h>

#include "weather.h"

int min_temp(WeatherTable a);

void max_temp(WeatherTable a, int max_temp[YEARS]);

void rainfall_month(WeatherTable a, int max_rainfall[YEARS]);

int pos(int a[MONTHS]);

#endif
