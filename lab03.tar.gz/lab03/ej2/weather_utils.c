#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "array_helpers.h"
#include "weather_utils.h"
#include "weather.h"

int min_temp(WeatherTable a){
    
    int res = a[0][0][0]._min_temp;
    
    for(int year = 0; year < LST_YEAR - FST_YEAR; year++){
        
        for(int month = 0; month < december; month++){
            
            for(int day = 0; day < LST_DAY; day++){
                
                if(a[year][month][day]._min_temp < res){
                    
                    res = a[year][month][day]._min_temp;
                
                }
            
            }
        
        }
    
    }

    return res;
}

void max_temp(WeatherTable a, int max_temp[YEARS]){
    
    for(int year = 0; year < YEARS; year++){
        
        int res = a[year][0][0]._max_temp;

        for(int month = 0; month < december; month++){
            
            for(int day = 0; day < LST_DAY; day++){
                
                if(a[year][month][day]._max_temp > res){
                    
                    res = a[year][month][day]._max_temp;
                
                }
            
            }
        
        }
        max_temp[year] = res;
    }

}


void rainfall_month(WeatherTable a, int max_rainfall[YEARS]){

    int month_rainfall[MONTHS];
    
    for(int year = 0; year < YEARS; year++){
        
        for(int month = 0; month < MONTHS; month++){
            
            int sum = 0;

            for(int day = 0; day < LST_DAY; day++){
                
                sum +=  a[year][month][day]._rainfall;
            
            }
        
            month_rainfall[month] = sum;

        }
            
        max_rainfall[year] = pos(month_rainfall);
    
    }

}
