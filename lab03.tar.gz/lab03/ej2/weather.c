/*
  @file weather.c
  @brief Implements weather mesuarement structure and methods
*/
#include <stdlib.h>
#include "weather.h"

static const int AMOUNT_OF_WEATHER_VARS = 6 ;

Weather weather_from_file(FILE* file)
{
    Weather weather;

    int average, max, min, res;

    unsigned int moisture,pressure,rainfall;
    
    res = fscanf(file, " %d %d %d %u %u %u", &average, &max, &min, &moisture, &pressure, &rainfall);
    if (res != AMOUNT_OF_WEATHER_VARS) {
        if (res == EOF) {
            /* Llegamos al final del archivo */
            exit(EXIT_SUCCESS);
        } else {
            /* Hubo un error al leer los datos */
            fprintf(stderr, "Error reading weather data.\n");
            exit(EXIT_FAILURE);
        }
    }

    weather._average_temp = average;
    weather._max_temp = max;
    weather._min_temp = min;
    weather._moisture = moisture;
    weather._pressure = pressure;
    weather._rainfall = rainfall;

    return weather;
}

void weather_to_file(FILE* file, Weather weather)
{
    fprintf(file, EXPECTED_WEATHER_FILE_FORMAT, weather._average_temp, 
            weather._max_temp, weather._min_temp, weather._pressure, weather._moisture, weather._rainfall);
}
