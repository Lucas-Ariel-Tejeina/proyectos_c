#ifndef Mb_H
#define Mb_H

#define true 1
#define false 0

typedef int mybool;

#endif