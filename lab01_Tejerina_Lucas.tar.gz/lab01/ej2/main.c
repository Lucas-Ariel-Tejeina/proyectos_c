/* First, the standard lib includes, alphabetically ordered */
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

/* Maximum allowed length of the array */
#define MAX_SIZE 100000

unsigned int require_size(){
    unsigned size;
    printf("Introduzca en tamaño del array.\n");
    scanf("%u",&size);
    return size;
}

void array_from_stdin(int a[], unsigned int length){
    printf("Introduzca los elementos del array.\n");
    for(unsigned int i = 0; i < length; i++){
        printf("Elemento en la posición %d: ",i);
        scanf("%d",&a[i]);
    };
}

void array_dump(int a[], unsigned int length) {
    printf("[");
    for(unsigned int i = 0; i < length; i++){
        if(i < length - 1){
            printf("%d,",a[i]);
        }else{
            printf("%d]\n",a[i]);
        };
    };   
}


int main() {
    
    int array[MAX_SIZE];
    
    unsigned int length;

    length = require_size();

    array_from_stdin(array,length);

    array_dump(array, length);
    
    return EXIT_SUCCESS;
}
