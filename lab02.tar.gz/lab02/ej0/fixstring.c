#include <stdbool.h>
#include <assert.h>

#include "fixstring.h"

unsigned int fstring_length(fixstring s) {
    unsigned int length = 1;
    for(int i = 0; i < FIXSTRING_MAX; i++){
        if(s[i] == '\0'){
            return length;
        };
        length++;
    }
    return length;
}

bool fstring_eq(fixstring s1, fixstring s2) {
    bool value = true;
    if(fstring_length(s1) != fstring_length(s2)){
        return value = false;
    };
    
    for(unsigned int i = 0; value && i < fstring_length(s1); i++){
        value = s1[i] == s2[i];
    };
    return value;
}

bool fstring_less_eq(fixstring s1, fixstring s2) {
    bool value = true;
    int length;
    if(fstring_length(s1) - fstring_length(s2) <= 0){
        length = fstring_length(s1);
    }else{
        length = fstring_length(s2);
    }
    for(int i = 0; i < length; i++){
        if(s1[i] < s2[i]){
            return value;
        }else if(s1[i] > s2[i]){
            return !value;
        }
    }
    return value;
}

